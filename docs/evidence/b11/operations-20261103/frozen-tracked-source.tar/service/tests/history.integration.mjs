import test,{before,after} from 'node:test';
import assert from 'node:assert/strict';
import pg from 'pg';
import {randomUUID} from 'node:crypto';
import {generateKeyPair,exportJWK,createLocalJWKSet,SignJWT} from 'jose';
import {HouseholdRepository} from '../dist/repository.js';
import {JWTIdentityVerifier,SupabaseSessionVerifier} from '../dist/auth.js';
import {BillingService} from '../dist/billing/service.js';
import {createHTTPServer} from '../dist/http.js';
const admin=new pg.Pool({connectionString:process.env.TEST_ADMIN_DATABASE_URL}),runtime=new pg.Pool({connectionString:process.env.TEST_DATABASE_URL}),subscriptions=new Map();let verifiedCalls=0;
const gateway={verifyTransaction:async value=>{const current=subscriptions.get(value);if(!current)throw Error('fixture signature');return current;},current:async id=>{verifiedCalls++;const value=subscriptions.get(id);if(!value)throw Error('fixture unavailable');return value;},verifyNotification:async()=>{throw Error('unused');}};
const issuer='https://history.fixture.invalid',audience='authenticated';const {publicKey,privateKey}=await generateKeyPair('ES256'),jwk=await exportJWK(publicKey);jwk.kid='history';
const verifier=new JWTIdentityVerifier({issuer,audience,jwksUrl:issuer+'/keys'},createLocalJWKSet({keys:[jwk]})),repo=new HouseholdRepository(runtime,{allowChildNetwork:false,noticeVersion:'fixture',sessionStatus:new SupabaseSessionVerifier(issuer)}),billing=new BillingService(gateway),server=createHTTPServer({repository:repo,verifier,billing,maxRequestsPerMinute:20000});let origin;
before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;});after(async()=>{await new Promise(r=>server.close(r));await Promise.all([admin.end(),runtime.end()]);});
async function actor(){const subject=randomUUID(),session=randomUUID();await admin.query('INSERT INTO auth.sessions(id,user_id) VALUES($1,$2)',[session,subject]);const token=await new SignJWT({session_id:session}).setProtectedHeader({alg:'ES256',kid:jwk.kid}).setIssuer(issuer).setSubject(subject).setAudience(audience).setIssuedAt().setExpirationTime('1h').sign(privateKey);return{subject,session,token};}
async function call(a,path,method='GET',body,headers={}){const r=await fetch(origin+path,{method,headers:{Authorization:'Bearer '+a.token,...(a.device?{'X-Device-Token':a.device}:{}),...(body===undefined?{}:{'Content-Type':'application/json'}),...headers},...(body===undefined?{}:{body:JSON.stringify(body)})});return{status:r.status,data:await r.json()};}
function ok(r,status=200){assert.equal(r.status,status,JSON.stringify(r.data));return r.data;}
async function enroll(a,h){a.device=ok(await call(a,`/v1/households/${h}/devices`,'POST',{}),201).deviceToken;a.window=ok(await call(a,`/v1/households/${h}/replay-windows`,'POST',{})).id;}
async function fixture(){const owner=await actor(),created=ok(await call(owner,'/v1/households','POST',{clientKey:randomUUID(),label:'History fixture',alias:'Adult',adultAttestation:true}),201),h=created.householdId,base=`/v1/households/${h}`;owner.id=created.memberId;await enroll(owner,h);
 const shop=async(price=10000)=>{const id=randomUUID(),quote={currency:'USD',scope:'wholeCheckout',complete:true,capMinor:100000,capScope:'wholeCheckout',fee:{kind:'fixed',amountMinor:0},taxesMinor:0,depositsMinor:0,discountsMinor:0,observedAt:new Date(Date.now()-60000).toISOString(),expiresAt:new Date(Date.now()+3600000).toISOString()};ok(await call(owner,base+'/commands','POST',{v:1,replayWindow:owner.window,clientKey:randomUUID(),shopId:id,kind:'shop.create',base:{shopRevision:0,authorityEpoch:0},body:{quote,lines:[{lineId:randomUUID(),originalItem:'Private basket source',packs:1,unitPriceMinor:price,feeEligible:true}]}}));return id;};
 const shopId=await shop();async function paid(){const token=ok(await call(owner,base+'/billing/purchase-context','POST',{})).appAccountToken,original=String(Date.now())+String(Math.floor(Math.random()*1e6)),now=Date.now();subscriptions.set(original,{environment:'Sandbox',originalTransactionID:original,transactionID:original,appAccountToken:token,productID:'fixture.household.yearly',purchasedAt:now,signedAt:now,expiresAt:now+3600000,graceExpiresAt:null,status:'active'});ok(await call(owner,'/v1/billing/verify','POST',{householdId:h,signedTransactionInfo:original}));return original;}
 const version=async(id=shopId)=>ok(await call(owner,base+`/shops/${id}/financial-evidence`)).sourceVersion;
 const financial=async(entry,id=shopId)=>{const input={clientKey:randomUUID(),sourceVersion:await version(id),entry};return{input,result:ok(await call(owner,base+`/shops/${id}/financial-evidence`,'POST',input))};};
 return{owner,h,base,shopId,shop,paid,version,financial};}
const entry=(kind,amountMinor,extra={})=>({id:randomUUID(),evidenceKey:randomUUID(),kind,amountMinor,currency:'USD',occurredAt:new Date().toISOString(),creditId:null,chargeEvidenceKey:null,holdEvidenceKey:null,sourceText:'Fictional entered evidence',...extra});
const observation=shopId=>({id:randomUUID(),shopId,itemName:'Cereal original',packLabel:'3 × 12 oz',usablePack:{amount:{numerator:36,denominator:1},unit:'ounce',originalLiteral:'36 oz'},price:{kind:'bounded',lowerMinor:500,upperMinor:700,reason:'Member offer not confirmed'},currency:'USD',store:'Store original',branch:'Branch original',channel:'warehouse',mode:'inStore',eligibility:'Membership not confirmed',observedAt:new Date().toISOString(),sourceText:'Original source text',sourceLocale:'es-US'});
const period=(ids)=>({id:randomUUID(),title:'Private pay-period title',startsAt:new Date(Date.now()-86400000).toISOString(),endsAt:new Date(Date.now()+86400000).toISOString(),timeZoneId:'America/Los_Angeles',currency:'USD',shopBudgetMinor:50000,alreadyExcludedReserveMinor:99999,shopIds:ids,reservations:[{id:randomUUID(),originalText:'Future plan secret',amountMinor:5000,plannedAt:new Date().toISOString(),state:{kind:'reserved'}}],reviewedCompleteAt:null});

test('Free manual evidence and saved observations remain accessible while paid history is gated',async()=>{
 const f=await fixture(),charge=entry('postedCharge',4000),recorded=await f.financial(charge);assert.equal(recorded.result.evidenceSource,'shopper_reported');assert.deepEqual(ok(await call(f.owner,f.base+`/shops/${f.shopId}/financial-evidence`,'POST',recorded.input)),recorded.result);
 const o=observation(f.shopId),input={clientKey:randomUUID(),observation:o};ok(await call(f.owner,f.base+'/price-observations','POST',input));assert.deepEqual(ok(await call(f.owner,f.base+'/price-observations/'+o.id)).observation,o);
 assert.equal((await call(f.owner,f.base+'/price-observations')).data.error.code,'membership_inactive');assert.equal((await call(f.owner,f.base+'/budget-history','POST',{shopIds:[f.shopId]})).data.error.code,'membership_inactive');
 assert.equal((await call(f.owner,f.base+`/shops/${f.shopId}`)).status,200);
 const closed=ok(await call(f.owner,f.base+`/shops/${f.shopId}/financial-reviews`,'POST',{clientKey:randomUUID(),sourceVersion:await f.version(),allEvidenceEntered:false,closeShop:true}));assert.equal(closed.appShopClosed,true);assert.equal(closed.reconciledEntered,false);assert.equal((await call(f.owner,f.base+'/price-observations','POST',{...input,observation:{...o,sourceText:'Changed'}})).data.error.code,'key_reused');
});
test('fresh paid history keeps inclusive estimates, posted cash, pending/included credits and holds distinct',async()=>{
 const f=await fixture();await f.paid();const charge=entry('postedCharge',4000);await f.financial(charge);const credit=randomUUID();await f.financial(entry('pendingCredit',500,{creditId:credit,chargeEvidenceKey:charge.evidenceKey}));const hold=entry('paymentHold',6000);await f.financial(hold);
 const before=verifiedCalls,history=ok(await call(f.owner,f.base+'/budget-history','POST',{shopIds:[f.shopId]})).permitted;assert.ok(verifiedCalls>before);assert.equal(history.postedNetMinor,4000);assert.equal(history.pendingCreditsMinor,500);assert.equal(history.paymentHoldsMinor,6000);assert.deepEqual(history.projectedCommitment,{lowerMinor:10000,upperMinor:10000});assert.deepEqual(history.expectedUnpaid,{lowerMinor:6000,upperMinor:6000});assert.equal(JSON.stringify(history).includes('Fictional entered evidence'),false);
 await f.financial(entry('includedCredit',500,{creditId:credit,chargeEvidenceKey:charge.evidenceKey}));await f.financial(entry('holdRelease',6000,{holdEvidenceKey:hold.evidenceKey}));
 let review={clientKey:randomUUID(),sourceVersion:await f.version(),allEvidenceEntered:true,closeShop:false};assert.equal(ok(await call(f.owner,f.base+`/shops/${f.shopId}/financial-reviews`,'POST',review)).reconciledEntered,false);
 review={clientKey:randomUUID(),sourceVersion:await f.version(),allEvidenceEntered:false,closeShop:true};const closed=ok(await call(f.owner,f.base+`/shops/${f.shopId}/financial-reviews`,'POST',review));assert.equal(closed.appShopClosed,true);assert.equal(closed.reconciledEntered,false);
 review={clientKey:randomUUID(),sourceVersion:await f.version(),allEvidenceEntered:true,closeShop:false};const reconciled=ok(await call(f.owner,f.base+`/shops/${f.shopId}/financial-reviews`,'POST',review));assert.equal(reconciled.reconciledEntered,true);
 assert.equal(ok(await call(f.owner,f.base+'/budget-history','POST',{shopIds:[f.shopId]})).permitted.projectedCommitment.lowerMinor,4000);
 await f.financial(entry('postedTopUp',100));const changed=ok(await call(f.owner,f.base+'/budget-history','POST',{shopIds:[f.shopId]})).permitted;assert.equal(changed.shops[0].reconciledEntered,false);assert.equal(changed.postedNetMinor,4100);assert.equal(changed.projectedCommitment.lowerMinor,10000);
 assert.equal((await call(f.owner,f.base+`/shops/${f.shopId}/financial-reviews`,'POST',{...review,clientKey:randomUUID()})).data.error.code,'stale_source');
});
test('period totals include linked later credits and count an applied reservation exactly once',async()=>{
 const f=await fixture();await f.paid();const p=period([f.shopId]);p.startsAt=new Date(Date.now()-4*86400000).toISOString();p.endsAt=new Date(Date.now()-3*86400000).toISOString();p.reservations.push({id:randomUUID(),originalText:'Applied planned amount',amountMinor:3000,plannedAt:new Date().toISOString(),state:{kind:'applied',shopId:f.shopId}});const input={clientKey:randomUUID(),baseRevision:0,period:p};const receipt=ok(await call(f.owner,f.base+'/budget-periods','POST',input));assert.equal(receipt.revision,1);assert.deepEqual(ok(await call(f.owner,f.base+'/budget-periods')).periods.map(x=>x.periodId),[p.id]);assert.deepEqual(ok(await call(f.owner,f.base+'/budget-periods','POST',input)),receipt);
 let summary=ok(await call(f.owner,f.base+'/budget-periods/'+p.id));assert.equal(summary.futureReservedMinor,5000);assert.deepEqual(summary.remaining,{minimumMinor:35000,maximumMinor:35000});assert.equal(summary.period.alreadyExcludedReserveMinor,99999);
 const charge=entry('postedCharge',12000,{occurredAt:new Date(Date.now()-3.5*86400000).toISOString()});await f.financial(charge);await f.financial(entry('postedCredit',1000,{creditId:randomUUID(),chargeEvidenceKey:charge.evidenceKey,occurredAt:new Date().toISOString()}));summary=ok(await call(f.owner,f.base+'/budget-periods/'+p.id));assert.equal(summary.permitted.postedNetMinor,11000);assert.equal(summary.remaining.maximumMinor,34000);
 const changed={...p,reservations:p.reservations.map(r=>({...r,state:{kind:'reserved'}}))};assert.equal((await call(f.owner,f.base+'/budget-periods','POST',{clientKey:randomUUID(),baseRevision:1,period:changed})).data.error.code,'reservation_final');
});
test('lost shop authority yields only independently permitted subtotal with no hidden funding or counts',async()=>{
 const f=await fixture();await f.paid();const second=await f.shop(20000),p=period([f.shopId,second]),input={clientKey:randomUUID(),baseRevision:0,period:p};ok(await call(f.owner,f.base+'/budget-periods','POST',input));assert.equal(ok(await call(f.owner,f.base+'/budget-periods/'+p.id)).remaining.maximumMinor,15000);
 const other=await actor(),link=ok(await call(f.owner,f.base+'/invites','POST',{kind:'adult_contributor'}));other.id=ok(await call(other,'/v1/invites/redeem','POST',{token:link.token,intent:'join',adultAttestation:true,alias:'Other adult'})).memberId;await enroll(other,f.h);
 ok(await call(f.owner,f.base+'/commands','POST',{v:1,replayWindow:f.owner.window,clientKey:randomUUID(),shopId:second,kind:'shop.transferAuthority',base:{shopRevision:1,authorityEpoch:1},body:{newShopperId:other.id}}));
 const partial=ok(await call(f.owner,f.base+'/budget-periods/'+p.id));assert.deepEqual(Object.keys(partial),['permitted']);assert.deepEqual(partial.permitted.shops.map(s=>s.shopId),[f.shopId]);assert.equal(partial.permitted.projectedCommitment.lowerMinor,10000);
 for(const secret of [second,p.title,'Future plan secret','50000','99999','hidden','remaining','reservations'])assert.equal(JSON.stringify(partial).includes(secret),false,secret);
 assert.deepEqual(ok(await call(f.owner,f.base+'/budget-history','POST',{shopIds:[f.shopId,second,randomUUID()]})),partial);
 assert.equal((await call(f.owner,f.base+'/budget-periods/'+p.id+'/record')).status,404);assert.equal((await call(f.owner,f.base+'/budget-periods','POST',input)).status,404);
 const retire={clientKey:randomUUID(),sourceVersion:await f.version(),confirm:true};ok(await call(f.owner,f.base+`/shops/${f.shopId}/history-retire`,'POST',retire));assert.deepEqual(ok(await call(f.owner,f.base+'/budget-periods/'+p.id)).permitted.shops,[]);
});
test('price observations preserve pack/channel context and paid lapse never erases saved raw records',async()=>{
 const f=await fixture(),original=await f.paid(),o=observation(f.shopId);ok(await call(f.owner,f.base+'/price-observations','POST',{clientKey:randomUUID(),observation:o}));const web={...observation(f.shopId),channel:'retailerWebsite',mode:'delivery',price:{kind:'unknown',reason:'No reviewed price'}};ok(await call(f.owner,f.base+'/price-observations','POST',{clientKey:randomUUID(),observation:web}));const rows=ok(await call(f.owner,f.base+'/price-observations')).observations;assert.equal(rows.length,2);assert.deepEqual(rows.find(x=>x.id===o.id),o);assert.deepEqual(rows.find(x=>x.id===web.id),web);
 subscriptions.set(original,{...subscriptions.get(original),status:'expired',signedAt:Date.now()+1});assert.equal((await call(f.owner,f.base+'/price-observations')).data.error.code,'membership_inactive');assert.deepEqual(ok(await call(f.owner,f.base+'/price-observations/'+o.id)).observation,o);
 assert.equal((await call(f.owner,f.base+'/price-observations','POST',{clientKey:randomUUID(),observation:{...observation(f.shopId),authority:'imported owner'}})).status,422);
 await admin.query('DELETE FROM auth.sessions WHERE id=$1',[f.owner.session]);assert.equal((await call(f.owner,f.base+'/price-observations/'+o.id)).status,401);
});

test('named paid status never grants another adult budget authority and currency/credit links stay exact',async()=>{
 const f=await fixture();await f.paid();const other=await actor(),link=ok(await call(f.owner,f.base+'/invites','POST',{kind:'adult_contributor'}));other.id=ok(await call(other,'/v1/invites/redeem','POST',{token:link.token,intent:'join',adultAttestation:true,alias:'Paid colleague'})).memberId;await enroll(other,f.h);
 const state=ok(await call(f.owner,f.base+'/entitlements'));ok(await call(f.owner,f.base+'/billing/seats','PUT',{revision:state.revision,userIDs:[f.owner.id,other.id]}));
 const empty=ok(await call(other,f.base+'/budget-history','POST',{shopIds:[f.shopId,randomUUID()]}));assert.deepEqual(empty.permitted.shops,[]);assert.equal(empty.permitted.postedNetMinor,0);
 assert.equal((await call(other,f.base+`/shops/${f.shopId}/financial-evidence`)).status,404);
 const badCredit=entry('postedCredit',100,{creditId:randomUUID(),chargeEvidenceKey:randomUUID()});assert.equal((await call(f.owner,f.base+`/shops/${f.shopId}/financial-evidence`,'POST',{clientKey:randomUUID(),sourceVersion:await f.version(),entry:badCredit})).status,422);
 assert.equal((await call(f.owner,f.base+`/shops/${f.shopId}/financial-evidence`,'POST',{clientKey:randomUUID(),sourceVersion:await f.version(),entry:{...entry('postedCharge',100),currency:'EUR'}})).status,422);
 assert.equal((await call(f.owner,f.base+'/price-observations','POST',{clientKey:randomUUID(),observation:{...observation(f.shopId),itemName:'🥣'.repeat(200)}})).status,422);
 await admin.query('DELETE FROM ritc.billing_seat WHERE household_id=$1 AND member_id=$2',[f.h,other.id]);assert.equal((await call(other,f.base+'/budget-history','POST',{shopIds:[]})).data.error.code,'membership_inactive');
});

test('history pagination retains submillisecond boundaries and rejects foreign source cursors',async()=>{
 const f=await fixture();await f.paid();await admin.query(`INSERT INTO ritc.financial_entry(household_id,shop_id,entry_id,evidence_key,actor_id,kind,amount_minor,occurred_at,source_text,created_at) SELECT $1,$2,gen_random_uuid(),gen_random_uuid(),$3,'postedCharge',1,now(),'Pagination fixture','2026-01-01 00:00:00.123456+00' FROM generate_series(1,51)`,[f.h,f.shopId,f.owner.id]);
 const path=f.base+'/shops/'+f.shopId+'/financial-evidence',a=ok(await call(f.owner,path)),b=ok(await call(f.owner,path+'?cursor='+a.nextCursor));assert.equal(a.entries.length,50);assert.equal(b.entries.length,1);assert.equal(new Set([...a.entries,...b.entries].map(e=>e.id)).size,51);assert.equal(b.nextCursor,null);assert.equal((await call(f.owner,path+'?cursor='+randomUUID())).status,404);
 const o=observation(f.shopId);await admin.query(`INSERT INTO ritc.price_observation(household_id,observation_id,shop_id,actor_id,record,observed_at) SELECT $1,id,$2,$3,jsonb_set($4::jsonb,'{id}',to_jsonb(id::text)),'2026-01-01 00:00:00.123456+00' FROM (SELECT gen_random_uuid() AS id FROM generate_series(1,101)) fixture`,[f.h,f.shopId,f.owner.id,o]);
 const c=ok(await call(f.owner,f.base+'/price-observations')),d=ok(await call(f.owner,f.base+'/price-observations?cursor='+c.nextCursor));assert.equal(c.observations.length,100);assert.equal(d.observations.length,1);assert.equal(new Set([...c.observations,...d.observations].map(e=>e.id)).size,101);assert.equal(d.nextCursor,null);assert.equal((await call(f.owner,f.base+'/price-observations?cursor='+randomUUID())).status,404);
});

test('explicit planner access and an active adult seat allow proposing an exact move without basket or budget access',async()=>{
 const f=await fixture(), base=f.base+'/shops/'+f.shopId, plan=base+'/meal-plan';
 const alex=await actor(),invite=ok(await call(f.owner,f.base+'/invites','POST',{kind:'adult_contributor'}));
 alex.id=ok(await call(alex,'/v1/invites/redeem','POST',{token:invite.token,intent:'join',adultAttestation:true,alias:'Alex'})).memberId;
 await enroll(alex,f.h);
 const initial=ok(await call(f.owner,base)), occurrenceId=randomUUID();
 const patch=(revision,mealEdit)=>({v:1,replayWindow:f.owner.window,clientKey:randomUUID(),shopId:f.shopId,kind:'shop.patch',
  base:{shopRevision:revision,authorityEpoch:1},body:{quote:initial.quote,lines:initial.lines,mealEdit}});
 const meal={title:'Thursday soup',kind:'dinner',portions:4,day:'2026-11-05',protected:false};
 ok(await call(f.owner,f.base+'/commands','POST',patch(1,{occurrenceId,baseMealRevision:null,meal})));
 await f.paid();const seats=ok(await call(f.owner,f.base+'/entitlements'));
 ok(await call(f.owner,f.base+'/billing/seats','PUT',{revision:seats.revision,userIDs:[f.owner.id,alex.id]}));
 assert.equal((await call(alex,plan)).status,404);
 const grant={authorityEpoch:1,grantRevision:0,plannerId:alex.id};
 ok(await call(f.owner,plan+'/planner','PUT',grant));
 ok(await call(f.owner,plan+'/planner','PUT',grant));
 assert.ok(ok(await call(alex,f.base+'/bootstrap')).capabilities.includes('meal_proposals'));
 const read=ok(await call(alex,plan));
 assert.deepEqual(read.adults,[]);assert.equal(read.meals[0].meal.day,meal.day);
 assert.equal(read.quote,undefined);assert.equal(read.lines,undefined);assert.equal((await call(alex,base)).status,404);
 const move={proposalId:randomUUID(),occurrenceId,day:'2026-11-08',shopRevision:2,authorityEpoch:1,grantRevision:1};
 ok(await call(alex,plan+'/proposals','POST',move));ok(await call(alex,plan+'/proposals','POST',move));
 assert.equal((await call(alex,plan+'/proposals','POST',{...move,day:'2026-11-09'})).status,409);
 const alternate={...move,proposalId:randomUUID(),day:'2026-11-10'};
 ok(await call(alex,plan+'/proposals','POST',alternate));
 const dismissal={proposalId:alternate.proposalId,shopRevision:2,authorityEpoch:1,grantRevision:1};
 assert.equal((await call(alex,plan+'/dismissals','POST',dismissal)).status,404);
 ok(await call(f.owner,plan+'/dismissals','POST',dismissal));
 ok(await call(f.owner,plan+'/dismissals','POST',dismissal));
 assert.equal(ok(await call(f.owner,plan)).proposals.length,1);
 assert.equal(ok(await call(f.owner,base)).shopRevision,2);
 const accepted=patch(2,{occurrenceId,baseMealRevision:2,meal:{...meal,day:move.day},proposalId:move.proposalId});
 assert.equal((await call(f.owner,f.base+'/commands','POST',patch(2,{...accepted.body.mealEdit,meal:{...meal,day:'2026-11-12'}}))).status,409);
 const receipt=ok(await call(f.owner,f.base+'/commands','POST',accepted));
 assert.equal(receipt.shopRevision,3);assert.deepEqual(ok(await call(f.owner,f.base+'/commands','POST',accepted)),receipt);
 assert.equal(ok(await call(alex,plan)).meals[0].meal.day,move.day);
 const current=ok(await call(f.owner,f.base+'/entitlements'));
 ok(await call(f.owner,f.base+'/billing/seats','PUT',{revision:current.revision,userIDs:[f.owner.id]}));
 assert.equal((await call(alex,plan)).data.error.code,'membership_inactive');
 ok(await call(f.owner,plan+'/planner','PUT',{...grant,grantRevision:1,plannerId:null}));
 assert.equal((await call(alex,plan+'/proposals','POST',move)).status,404);
 assert.equal(ok(await call(alex,f.base+'/bootstrap')).capabilities.includes('meal_proposals'),false);
});

if (process.env.RITC_TEST_NATIVE_WIRE === '1') {
 for(const paid of [false,true]) {
  test(`Swift household client records meals and price history over HTTPS and PostgreSQL (paid=${paid})`,async()=>{
   const {exerciseNativeClient}=await import('./native-wire.mjs');
   const f=await fixture(), second=await f.shop(), record=observation(f.shopId);
   if(paid) await f.paid();
   ok(await call(f.owner,f.base+'/price-observations','POST',{clientKey:randomUUID(),observation:record}));
   await exerciseNativeClient({service:server,owner:f.owner,householdId:f.h,shopId:f.shopId,secondShopId:second,observationId:record.id,paid});
  });
 }
}
