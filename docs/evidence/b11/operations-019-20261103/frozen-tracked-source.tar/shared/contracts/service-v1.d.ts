/** Service v1 wire contracts. All IDs are opaque UUIDs. Money is integer USD cents. */
export type RequestStatus = 'pending' | 'clarified' | 'added' | 'deferred' | 'handled' | 'dismissed' | 'withdrawn';
export interface OwnRequest {
  requestId: string; shopId: string; revision: number; originalItem: string; ownQuantity: string | null;
  authoredAt: string; receivedAt: string; route: 'current' | 'next'; status: RequestStatus;
  ownActionAllowed: boolean; clarification: string | null; followupTo: string | null;
}
export interface CommandBase { shopRevision: number; authorityEpoch: number; requestRevision?: number }
export interface CommandEnvelope {
  v: 1; replayWindow: string; clientKey: string; shopId: string;
  kind: string; base: CommandBase; body: Record<string, unknown>;
}
export interface OwnReceipt { operationId: string; kind: string; request: OwnRequest }
export interface ShopperReceipt {
  operationId: string; kind: string; shopId: string; shopRevision: number; authorityEpoch: number;
  disposition: string; requestId?: string; requestRevision?: number; reportId?: string;
}
export type FeeRule = { kind: 'fixed'; amountMinor: number | null } |
  { kind: 'threshold'; thresholdMinor: number; belowMinor: number | null; aboveMinor: number | null };
export interface BasketLine { lineId: string; originalItem: string; packs: number; unitPriceMinor: number | null; feeEligible: boolean }
export interface QuoteBasis {
  currency: 'USD'; scope: 'wholeCheckout' | 'item' | 'dinner'; complete: boolean; capMinor: number | null; capScope: 'wholeCheckout' | 'item' | 'dinner' | 'unknown';
  fee: FeeRule; taxesMinor: number | null; depositsMinor: number | null; discountsMinor: number | null;
  observedAt: string; expiresAt: string;
}
export interface BudgetResult {
  currency: 'USD'; totalMinor: number | null; overCapMinor: number | null; headroomMinor: number | null;
  status: 'withinCap' | 'overCap' | 'unresolved' | 'scopeMismatch'; scope: QuoteBasis['scope']; missing: string[];
  lowerBoundMinor: number; upperBoundMinor: number | null; wholeCheckoutWithinCap: boolean;
}
export interface RequestPreview {
  previewId: string; expiresAt: string; shopRevision: number; authorityEpoch: number; requestRevision: number;
  choice: 'add' | 'link' | 'defer' | 'dismiss' | 'handled'; before: BudgetResult; after: BudgetResult;
  changeMinor: number | null; requiresOverageAcceptance: boolean; requiresUnknownAcceptance: boolean;
}
export interface ServiceError { error: { code: string; correlationId: string; recovery: string } }

export interface SharedMealAmount { numerator: number; denominator: number }
export interface SharedMealQuantity {
  amount: SharedMealAmount;
  unit: 'count'|'gram'|'kilogram'|'ounce'|'pound'|'milliliter'|'liter'|'fluidOunce'|'cup';
  originalLiteral: string;
}
export interface SharedMealPlanning {
  sourceOccurrenceId?: string; // Explicit reviewed local-to-shared mapping; never an authority claim.
  groups: Array<{id:string;name:string;servings:SharedMealAmount;protected:boolean}>;
  ingredients: Array<{id:string;name:string;quantity:SharedMealQuantity|null;groupIds:string[];exclusions:string[]}>;
  bindings?: Array<{id:string;groupId:string;ingredientId:string;quantity:SharedMealQuantity}>;
}
export interface SharedMeal {
  title: string;
  day: string; // Civil date, YYYY-MM-DD
  kind: 'dinner' | 'lunch' | 'side';
  portions: number;
  protected: boolean;
  planning?: SharedMealPlanning;
}
export interface SharedMealEdit {
  occurrenceId: string;
  baseMealRevision: number | null;
  meal: SharedMeal | null;
  proposalId?: string;
  changeProposalId?: string; // Mutually exclusive with date proposalId.
}
export interface SharedMealPlan {
  shopId: string;
  shopRevision: number;
  authorityEpoch: number;
  grantRevision: number;
  shopper: boolean;
  plannerId: string | null;
  adults: Array<{ id: string; label: string }>;
  meals: Array<{ occurrenceId: string; revision: number; meal: SharedMeal }>;
  proposals: Array<{ proposalId: string; occurrenceId: string; day: string }>;
}

/** Private, optional shopper add-decision provenance; never part of an author/child projection. */
export interface ReviewedRequestPackQuantity { numerator:string; denominator:string; unit:'count'|'gram'|'kilogram'|'ounce'|'pound'|'milliliter'|'liter'|'fluidOunce'|'cup'; originalLiteral:string }
export interface ReviewedRequestPackEvidence {
  version:1; offerId:string; label:string; needed:ReviewedRequestPackQuantity; usablePerPack:ReviewedRequestPackQuantity;
  packs:number; unitPriceMinor:number|null; productMatchConfirmed:true; availabilityConfirmed:true; availablePackLimit:number|null;
  quoteSource:string; quoteObservedAt:string; reviewedAt:string;
}
export type ShopperRequestDecision={choice:'add';line:BasketLine;promote:boolean;reviewedPackEvidence?:ReviewedRequestPackEvidence}|{choice:'link';lineId:string;promote:boolean}|{choice:'defer'|'dismiss'|'handled'};

/** Existing occurrence changes require positive baseMealRevision, an unchanged date, and the current named planning adult. */
export interface SharedMealChangeRequest {
  proposalId: string;
  occurrenceId: string;
  baseMealRevision: number | null;
  shopRevision: number;
  authorityEpoch: number;
  grantRevision: number;
  meal: SharedMeal;
  reason: string;
  approvedIdeaId?: string; // Required with approvedIdeaRevision for explicit new-occurrence creation only.
  approvedIdeaRevision?: number;
}
export interface SharedMealChangePage {
  shopId: string;
  shopRevision: number;
  authorityEpoch: number;
  grantRevision: number;
  phase: 'draft'|'frozen'|'placed'|'closed';
  shopper: boolean;
  meals: Array<{occurrenceId:string;revision:number;meal:SharedMeal}>;
  proposals: Array<{proposalId:string;request:SharedMealChangeRequest;original:SharedMeal|null;state:'pending'|'applied'|'dismissed'}>;
}
