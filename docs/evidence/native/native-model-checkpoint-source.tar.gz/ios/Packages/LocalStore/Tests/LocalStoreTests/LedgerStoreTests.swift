import XCTest
import Foundation
import CSQLite
@testable import LocalStore

final class LedgerStoreTests: XCTestCase {
    private var directory: URL!
    private var url: URL { directory.appendingPathComponent("ledger.sqlite") }
    private let originalDate = Date(timeIntervalSince1970: 1_700_000_000)

    override func setUpWithError() throws {
        directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    }

    override func tearDownWithError() throws {
        try FileManager.default.removeItem(at: directory)
    }

    func testEmptyMigrationAndIndependentWorkspace() async throws {
        try sql("PRAGMA user_version = 0")
        let store = try LedgerStore(url: url)
        let other = try LedgerStore(url: directory.appendingPathComponent("other.sqlite"))
        let empty = try await store.load()
        XCTAssertNil(empty)
        XCTAssertNotEqual(store.workspaceID, other.workspaceID)
        XCTAssertEqual(try scalar("PRAGMA user_version"), 1)
        XCTAssertEqual(try scalar("SELECT count(*) FROM ledger_workspace"), 1)
        XCTAssertEqual(try scalar("SELECT count(*) FROM ledger_revisions"), 0)
        try await store.close()
        try await other.close()
    }

    func testSaveCloseReopenPreservesExactBytesWorkspaceOperationAndTime() async throws {
        let store = try LedgerStore(url: url)
        let operation = UUID()
        let time = Date(timeIntervalSinceReferenceDate: Double(815_000_000).nextUp)
        let payload = Data([0, 1, 2, 127, 255])
        let saved = try await store.save(payload: payload, expectedRevision: 0, operationID: operation, savedAt: time)
        XCTAssertEqual(saved.workspaceID, store.workspaceID)
        XCTAssertEqual(saved.revision, 1)
        XCTAssertEqual(saved.operationID, operation)
        XCTAssertEqual(saved.savedAt, time)
        try await store.close()
        let reopened = try LedgerStore(url: url)
        let loaded = try await reopened.load()
        XCTAssertEqual(reopened.workspaceID, store.workspaceID)
        XCTAssertEqual(loaded, saved)
        XCTAssertEqual(try scalar("SELECT length(payload) FROM ledger_revisions"), Int64(payload.count))
        try await reopened.close()
    }

    func testConcurrentInitialOpenersShareOneMigratedWorkspace() async throws {
        let location = url
        let barrier = LedgerOpenBarrier(count: 20)
        var identities: Set<UUID> = []
        try await withThrowingTaskGroup(of: UUID.self) { group in
            for _ in 0..<20 {
                group.addTask {
                    await barrier.wait()
                    let store = try LedgerStore(url: location)
                    let identity = store.workspaceID
                    try await store.close()
                    return identity
                }
            }
            for try await identity in group { identities.insert(identity) }
        }
        XCTAssertEqual(identities.count, 1)
        XCTAssertEqual(try scalar("SELECT count(*) FROM ledger_workspace"), 1)
        XCTAssertEqual(try scalar("PRAGMA user_version"), 1)
    }

    func testOpeningWhileAnotherConnectionSavesUsesConsistentValidationSnapshot() async throws {
        let store = try LedgerStore(url: url)
        try await store.save(payload: Data([0]), expectedRevision: 0, operationID: UUID(), savedAt: originalDate)
        let location = url
        let date = originalDate
        let barrier = LedgerOpenBarrier(count: 13)
        try await withThrowingTaskGroup(of: UUID.self) { group in
            group.addTask {
                await barrier.wait()
                for base in Int64(1)...40 {
                    try await store.save(payload: Data([UInt8(base)]), expectedRevision: base, operationID: UUID(), savedAt: date)
                }
                return store.workspaceID
            }
            for _ in 0..<12 {
                group.addTask {
                    await barrier.wait()
                    for _ in 0..<5 {
                        let reader = try LedgerStore(url: location)
                        let record = try await reader.load()
                        XCTAssertNotNil(record)
                        XCTAssertEqual(reader.workspaceID, store.workspaceID)
                        try await reader.close()
                    }
                    return store.workspaceID
                }
            }
            for try await identity in group { XCTAssertEqual(identity, store.workspaceID) }
        }
        let loaded = try await store.load()
        XCTAssertEqual(loaded?.revision, 41)
        try await store.close()
    }

    func testExactOperationRetryAfterRestartAndNewerSaveReturnsOriginalResult() async throws {
        let store = try LedgerStore(url: url)
        let operation = UUID()
        let first = try await store.save(payload: Data([1]), expectedRevision: 0, operationID: operation, savedAt: originalDate)
        let second = try await store.save(payload: Data([2]), expectedRevision: 1, operationID: UUID(), savedAt: originalDate.addingTimeInterval(1))
        try await store.close()
        let reopened = try LedgerStore(url: url)
        let retry = try await reopened.save(payload: Data([1]), expectedRevision: 0, operationID: operation, savedAt: originalDate.addingTimeInterval(999))
        let loaded = try await reopened.load()
        XCTAssertEqual(retry, first)
        XCTAssertEqual(loaded, second)
        XCTAssertEqual(try scalar("SELECT count(*) FROM ledger_revisions"), 2)
        try await reopened.close()
    }

    func testReusedOperationWithChangedPayloadOrBaseFailsWithoutMutation() async throws {
        let store = try LedgerStore(url: url)
        let operation = UUID()
        let saved = try await store.save(payload: Data([1]), expectedRevision: 0, operationID: operation, savedAt: originalDate)
        for (payload, base) in [(Data([2]), Int64(0)), (Data([1]), Int64(1))] {
            do {
                try await store.save(payload: payload, expectedRevision: base, operationID: operation, savedAt: originalDate)
                XCTFail("Reusing an operation with changed intent must fail")
            } catch { XCTAssertEqual(error as? LedgerStoreError, .operationConflict) }
        }
        let loaded = try await store.load()
        XCTAssertEqual(loaded, saved)
        XCTAssertEqual(try scalar("SELECT count(*) FROM ledger_revisions"), 1)
        try await store.close()
    }

    func testDistinctOperationWithSamePayloadNeedsCurrentBaseAndAppendsReceipt() async throws {
        let store = try LedgerStore(url: url)
        let first = try await store.save(payload: Data(), expectedRevision: 0, operationID: UUID(), savedAt: originalDate)
        do {
            try await store.save(payload: Data(), expectedRevision: 0, operationID: UUID(), savedAt: originalDate)
            XCTFail("Equal payload must not bypass compare-and-swap")
        } catch { XCTAssertEqual(error as? LedgerStoreError, .staleRevision(expected: 0, actual: 1)) }
        let second = try await store.save(payload: Data(), expectedRevision: 1, operationID: UUID(), savedAt: originalDate)
        XCTAssertEqual(second.revision, 2)
        XCTAssertNotEqual(first.operationID, second.operationID)
        XCTAssertEqual(second.payload, Data())
        XCTAssertEqual(try scalar("SELECT count(*) FROM ledger_revisions WHERE typeof(payload) = 'blob' AND length(payload) = 0"), 2)
        try await store.close()
    }

    func testTwoConnectionsCannotCommitTheSameBaseTwice() async throws {
        let first = try LedgerStore(url: url)
        let second = try LedgerStore(url: url)
        let date = originalDate
        var successes = 0
        var stale = 0
        try await withThrowingTaskGroup(of: LedgerStoreError?.self) { group in
            for index in 0..<20 {
                let store = index.isMultiple(of: 2) ? first : second
                group.addTask {
                    do {
                        try await store.save(payload: Data([UInt8(index)]), expectedRevision: 0, operationID: UUID(), savedAt: date)
                        return nil
                    } catch let error as LedgerStoreError { return error }
                }
            }
            for try await error in group {
                if let error {
                    XCTAssertEqual(error, .staleRevision(expected: 0, actual: 1))
                    stale += 1
                } else { successes += 1 }
            }
        }
        XCTAssertEqual(successes, 1)
        XCTAssertEqual(stale, 19)
        XCTAssertEqual(try scalar("SELECT count(*) FROM ledger_revisions"), 1)
        try await first.close()
        try await second.close()
    }

    func testConcurrentExactRetriesHaveOneDurableResult() async throws {
        let first = try LedgerStore(url: url)
        let second = try LedgerStore(url: url)
        let operation = UUID()
        let date = originalDate
        var records: [LedgerRecord] = []
        try await withThrowingTaskGroup(of: LedgerRecord.self) { group in
            for index in 0..<20 {
                let store = index.isMultiple(of: 2) ? first : second
                group.addTask {
                    try await store.save(payload: Data([255]), expectedRevision: 0, operationID: operation,
                                         savedAt: date.addingTimeInterval(Double(index)))
                }
            }
            for try await record in group { records.append(record) }
        }
        let loaded = try await first.load()
        XCTAssertEqual(records.count, 20)
        XCTAssertTrue(records.allSatisfy { $0 == loaded })
        XCTAssertEqual(try scalar("SELECT count(*) FROM ledger_revisions"), 1)
        try await first.close()
        try await second.close()
    }

    func testSQLiteProtectsSnapshotAndWorkspaceIdentity() async throws {
        let store = try LedgerStore(url: url)
        let saved = try await store.save(payload: Data([1]), expectedRevision: 0, operationID: UUID(), savedAt: originalDate)
        XCTAssertThrowsError(try sql("UPDATE ledger_revisions SET payload = x'02'"))
        XCTAssertThrowsError(try sql("UPDATE ledger_revisions SET operation_id = '\(UUID().uuidString)'"))
        XCTAssertThrowsError(try sql("DELETE FROM ledger_revisions"))
        XCTAssertThrowsError(try sql("UPDATE ledger_workspace SET id = '\(UUID().uuidString)'"))
        XCTAssertThrowsError(try sql("DELETE FROM ledger_workspace"))
        let loaded = try await store.load()
        XCTAssertEqual(loaded, saved)
        try await store.close()
    }

    func testRevisionInsertFailureDoesNotAdvanceHead() async throws {
        let store = try LedgerStore(url: url)
        try sql("CREATE TRIGGER fail_revision BEFORE INSERT ON ledger_revisions BEGIN SELECT RAISE(ABORT, 'test failure'); END")
        do {
            try await store.save(payload: Data([1]), expectedRevision: 0, operationID: UUID(), savedAt: originalDate)
            XCTFail("Expected injected failure")
        } catch LedgerStoreError.database { }
        let loaded = try await store.load()
        XCTAssertNil(loaded)
        XCTAssertEqual(try scalar("SELECT count(*) FROM ledger_revisions"), 0)
        try await store.close()
    }

    func testInitialHeadFailureRollsBackSnapshotAndCanRetrySameOperation() async throws {
        let store = try LedgerStore(url: url)
        let operation = UUID()
        try sql("CREATE TRIGGER fail_head BEFORE UPDATE ON ledger_workspace BEGIN SELECT RAISE(ABORT, 'test failure'); END")
        do {
            try await store.save(payload: Data([1]), expectedRevision: 0, operationID: operation, savedAt: originalDate)
            XCTFail("Expected injected failure")
        } catch LedgerStoreError.database { }
        XCTAssertEqual(try scalar("SELECT count(*) FROM ledger_revisions"), 0)
        try await store.close()
        let reopened = try LedgerStore(url: url)
        let loaded = try await reopened.load()
        XCTAssertNil(loaded)
        try sql("DROP TRIGGER fail_head")
        let saved = try await reopened.save(payload: Data([1]), expectedRevision: 0, operationID: operation, savedAt: originalDate)
        XCTAssertEqual(saved.revision, 1)
        try await reopened.close()
    }

    func testLaterHeadFailurePreservesPriorSnapshotAfterRestart() async throws {
        let store = try LedgerStore(url: url)
        let saved = try await store.save(payload: Data([1]), expectedRevision: 0, operationID: UUID(), savedAt: originalDate)
        try sql("CREATE TRIGGER fail_head BEFORE UPDATE ON ledger_workspace BEGIN SELECT RAISE(ABORT, 'test failure'); END")
        do {
            try await store.save(payload: Data([2]), expectedRevision: 1, operationID: UUID(), savedAt: originalDate)
            XCTFail("Expected injected failure")
        } catch LedgerStoreError.database { }
        XCTAssertEqual(try scalar("SELECT count(*) FROM ledger_revisions"), 1)
        try await store.close()
        let reopened = try LedgerStore(url: url)
        let loaded = try await reopened.load()
        XCTAssertEqual(loaded, saved)
        try await reopened.close()
    }

    func testCommitFailureRollsBackBothMutationsBeforeReportingError() async throws {
        let store = try LedgerStore(url: url)
        let operation = UUID()
        // The statement succeeds; its deferred foreign key makes COMMIT itself fail.
        try sql("""
            CREATE TABLE commit_guard (id TEXT REFERENCES ledger_workspace(id) DEFERRABLE INITIALLY DEFERRED);
            CREATE TRIGGER fail_commit AFTER UPDATE ON ledger_workspace
            BEGIN INSERT INTO commit_guard VALUES ('missing-workspace'); END;
            """)
        do {
            try await store.save(payload: Data([1]), expectedRevision: 0, operationID: operation, savedAt: originalDate)
            XCTFail("A failed COMMIT must never report a save")
        } catch LedgerStoreError.database { }
        XCTAssertEqual(try scalar("SELECT count(*) FROM ledger_revisions"), 0)
        XCTAssertEqual(try scalar("SELECT count(*) FROM commit_guard"), 0)
        let loaded = try await store.load()
        XCTAssertNil(loaded)
        try sql("DROP TRIGGER fail_commit")
        let saved = try await store.save(payload: Data([1]), expectedRevision: 0, operationID: operation, savedAt: originalDate)
        XCTAssertEqual(saved.revision, 1)
        try await store.close()
    }

    func testMaximumRawPayloadReopensAndRetriesWithoutBase64Expansion() async throws {
        let store = try LedgerStore(url: url)
        let payload = Data(repeating: 255, count: LedgerStore.maximumPayloadBytes)
        let operation = UUID()
        let saved = try await store.save(payload: payload, expectedRevision: 0, operationID: operation, savedAt: originalDate)
        XCTAssertEqual(try scalar("SELECT length(payload) FROM ledger_revisions"), Int64(LedgerStore.maximumPayloadBytes))
        try await store.close()
        let reopened = try LedgerStore(url: url)
        let loaded = try await reopened.load()
        let retry = try await reopened.save(payload: payload, expectedRevision: 0, operationID: operation, savedAt: originalDate.addingTimeInterval(1))
        XCTAssertEqual(loaded, saved)
        XCTAssertEqual(retry, saved)
        XCTAssertEqual(try scalar("SELECT count(*) FROM ledger_revisions"), 1)
        try await reopened.close()
    }

    func testOversizedPayloadAndInvalidInputsLeaveExistingStateUnchanged() async throws {
        let store = try LedgerStore(url: url)
        let saved = try await store.save(payload: Data([1]), expectedRevision: 0, operationID: UUID(), savedAt: originalDate)
        do {
            try await store.save(payload: Data(count: LedgerStore.maximumPayloadBytes + 1), expectedRevision: 1, operationID: UUID(), savedAt: originalDate)
            XCTFail("Expected payload limit")
        } catch { XCTAssertEqual(error as? LedgerStoreError, .payloadTooLarge) }
        for (base, date) in [(Int64(-1), originalDate), (Int64(1), Date(timeIntervalSinceReferenceDate: .infinity))] {
            do {
                try await store.save(payload: Data(), expectedRevision: base, operationID: UUID(), savedAt: date)
                XCTFail("Expected invalid input")
            } catch { XCTAssertEqual(error as? LedgerStoreError, .invalidInput) }
        }
        let loaded = try await store.load()
        XCTAssertEqual(loaded, saved)
        XCTAssertEqual(try scalar("SELECT count(*) FROM ledger_revisions"), 1)
        try await store.close()
    }

    func testFutureSchemaIsByteForByteUnchanged() throws {
        try sql("CREATE TABLE future (value TEXT); INSERT INTO future VALUES ('preserve'); PRAGMA user_version = 42")
        let before = try Data(contentsOf: url)
        XCTAssertThrowsError(try LedgerStore(url: url)) { error in
            XCTAssertEqual(error as? LedgerStoreError, .unsupportedSchema(42))
        }
        XCTAssertEqual(try Data(contentsOf: url), before)
    }

    func testUnknownUnversionedSchemaIsByteForByteUnchanged() throws {
        try sql("CREATE TABLE legacy (value TEXT); INSERT INTO legacy VALUES ('preserve')")
        let before = try Data(contentsOf: url)
        XCTAssertThrowsError(try LedgerStore(url: url)) { error in
            XCTAssertEqual(error as? LedgerStoreError, .unrecognizedSchema)
        }
        XCTAssertEqual(try Data(contentsOf: url), before)
    }

    func testComparisonDatabaseCannotBeOpenedAsLedgerOrModified() async throws {
        let comparison = try ComparisonStore(url: url)
        try await comparison.save(id: UUID(), title: "Preserve", payload: Data([1]), savedAt: originalDate)
        try await comparison.close()
        let before = try Data(contentsOf: url)
        XCTAssertThrowsError(try LedgerStore(url: url)) { error in
            XCTAssertEqual(error as? LedgerStoreError, .unsupportedSchema(2))
        }
        XCTAssertEqual(try Data(contentsOf: url), before)
    }

    func testMalformedFileIsNotRecreated() throws {
        let before = Data("Not a SQLite database".utf8)
        try before.write(to: url)
        XCTAssertThrowsError(try LedgerStore(url: url))
        XCTAssertEqual(try Data(contentsOf: url), before)
    }

    func testCorruptEmptyVersionZeroIsNotMigratedOrRewritten() throws {
        try sql("PRAGMA user_version = 0")
        var before = try Data(contentsOf: url)
        // Corrupt the freelist without adding any application schema: page 2 does
        // not exist in this otherwise empty one-page SQLite database.
        before.replaceSubrange(32..<36, with: [0, 0, 0, 2])
        before.replaceSubrange(36..<40, with: [0, 0, 0, 1])
        try before.write(to: url)
        XCTAssertThrowsError(try LedgerStore(url: url))
        XCTAssertEqual(try Data(contentsOf: url), before)
    }

    func testDamagedHistoricalPayloadIsRejectedWithoutRewriting() async throws {
        let store = try LedgerStore(url: url)
        try await store.save(payload: Data([1]), expectedRevision: 0, operationID: UUID(), savedAt: originalDate)
        try await store.save(payload: Data([2]), expectedRevision: 1, operationID: UUID(), savedAt: originalDate)
        try await store.close()
        try sql("DROP TRIGGER ledger_revision_immutable_update; UPDATE ledger_revisions SET payload = x'03' WHERE revision = 1")
        let before = try Data(contentsOf: url)
        XCTAssertThrowsError(try LedgerStore(url: url)) { error in
            XCTAssertEqual(error as? LedgerStoreError, .corruptRecord)
        }
        XCTAssertEqual(try Data(contentsOf: url), before)
    }

    func testOversizedStoredPayloadIsRejectedWithoutRewriting() async throws {
        let store = try LedgerStore(url: url)
        try await store.save(payload: Data([1]), expectedRevision: 0, operationID: UUID(), savedAt: originalDate)
        try await store.close()
        try sql("""
            DROP TRIGGER ledger_revision_immutable_update;
            PRAGMA ignore_check_constraints = ON;
            UPDATE ledger_revisions SET payload = zeroblob(\(LedgerStore.maximumPayloadBytes + 1));
            """)
        let before = try Data(contentsOf: url)
        XCTAssertThrowsError(try LedgerStore(url: url))
        XCTAssertEqual(try Data(contentsOf: url), before)
    }

    func testBrokenHeadIsRejectedWithoutRewriting() async throws {
        let store = try LedgerStore(url: url)
        try await store.save(payload: Data([1]), expectedRevision: 0, operationID: UUID(), savedAt: originalDate)
        try await store.close()
        try sql("UPDATE ledger_workspace SET head_revision = 99")
        let before = try Data(contentsOf: url)
        XCTAssertThrowsError(try LedgerStore(url: url)) { error in
            XCTAssertEqual(error as? LedgerStoreError, .corruptRecord)
        }
        XCTAssertEqual(try Data(contentsOf: url), before)
    }

    func testClosedStoreFailsExplicitlyAndDoubleCloseIsSafe() async throws {
        let store = try LedgerStore(url: url)
        try await store.close()
        try await store.close()
        do {
            _ = try await store.load()
            XCTFail("Expected closed store error")
        } catch { XCTAssertEqual(error as? LedgerStoreError, .closed) }
        do {
            try await store.save(payload: Data(), expectedRevision: 0, operationID: UUID(), savedAt: originalDate)
            XCTFail("Expected closed store error")
        } catch { XCTAssertEqual(error as? LedgerStoreError, .closed) }
    }

    private func sql(_ query: String) throws {
        var database: OpaquePointer?
        guard sqlite3_open(url.path, &database) == SQLITE_OK else { throw TestError.sqlite }
        defer { sqlite3_close(database) }
        guard sqlite3_exec(database, query, nil, nil, nil) == SQLITE_OK else { throw TestError.sqlite }
    }

    private func scalar(_ query: String) throws -> Int64 {
        var database: OpaquePointer?
        guard sqlite3_open(url.path, &database) == SQLITE_OK else { throw TestError.sqlite }
        defer { sqlite3_close(database) }
        var row: OpaquePointer?
        guard sqlite3_prepare_v2(database, query, -1, &row, nil) == SQLITE_OK else { throw TestError.sqlite }
        defer { sqlite3_finalize(row) }
        guard sqlite3_step(row) == SQLITE_ROW else { throw TestError.sqlite }
        return sqlite3_column_int64(row, 0)
    }

    private enum TestError: Error { case sqlite }
}

private actor LedgerOpenBarrier {
    private var remaining: Int
    private var waiting: [CheckedContinuation<Void, Never>] = []

    init(count: Int) { remaining = count }

    func wait() async {
        remaining -= 1
        if remaining == 0 {
            for continuation in waiting { continuation.resume() }
            waiting.removeAll()
            return
        }
        await withCheckedContinuation { waiting.append($0) }
    }
}
