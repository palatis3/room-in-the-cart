-- Private per-shop grants. Membership, meal authority and a paid seat confer no budget access.
ALTER TABLE ritc.shop ADD COLUMN store_basis_revision integer;
CREATE TABLE ritc.shop_budget_grant (
 household_id uuid NOT NULL,shop_id uuid NOT NULL,member_id uuid NOT NULL,authority_epoch integer NOT NULL,
 revision integer NOT NULL CHECK(revision>0),enabled boolean NOT NULL,
 PRIMARY KEY(household_id,shop_id,member_id),
 FOREIGN KEY(household_id,shop_id) REFERENCES ritc.shop, FOREIGN KEY(household_id,member_id) REFERENCES ritc.member
);
CREATE INDEX shop_budget_grant_member ON ritc.shop_budget_grant(household_id,member_id,shop_id) WHERE enabled;
CREATE TABLE ritc.store_quote_pair (
 household_id uuid NOT NULL,shop_id uuid NOT NULL,pair_id uuid NOT NULL,actor_id uuid NOT NULL,
 shop_revision integer NOT NULL,authority_epoch integer NOT NULL,grant_revision integer NOT NULL,
 commitments jsonb NOT NULL,options jsonb NOT NULL,created_at timestamptz NOT NULL,
 PRIMARY KEY(household_id,shop_id,pair_id), FOREIGN KEY(household_id,shop_id) REFERENCES ritc.shop,
 FOREIGN KEY(household_id,actor_id) REFERENCES ritc.member
);
CREATE TABLE ritc.store_quote_proposal (
 household_id uuid NOT NULL,shop_id uuid NOT NULL,proposal_id uuid NOT NULL,pair_id uuid NOT NULL,choice text NOT NULL CHECK(choice IN ('first','second')),
 PRIMARY KEY(household_id,shop_id,proposal_id),
 FOREIGN KEY(household_id,shop_id,pair_id) REFERENCES ritc.store_quote_pair ON DELETE CASCADE
);
CREATE TABLE ritc.store_quote_adoption (
 household_id uuid NOT NULL,shop_id uuid NOT NULL,revision integer NOT NULL,pair_id uuid NOT NULL,choice text NOT NULL CHECK(choice IN ('first','second')),
 actor_id uuid NOT NULL, PRIMARY KEY(household_id,shop_id,revision),
 FOREIGN KEY(household_id,shop_id,pair_id) REFERENCES ritc.store_quote_pair ON DELETE CASCADE, FOREIGN KEY(household_id,actor_id) REFERENCES ritc.member
);
CREATE TABLE ritc.store_quote_mutation (
 household_id uuid NOT NULL,shop_id uuid NOT NULL,actor_id uuid NOT NULL,operation_id uuid NOT NULL,fingerprint text NOT NULL,receipt jsonb NOT NULL,
 PRIMARY KEY(household_id,shop_id,actor_id,operation_id),FOREIGN KEY(household_id,shop_id) REFERENCES ritc.shop,
 FOREIGN KEY(household_id,actor_id) REFERENCES ritc.member
);
DO $$ DECLARE t text; BEGIN
 FOREACH t IN ARRAY ARRAY['shop_budget_grant','store_quote_pair','store_quote_proposal','store_quote_adoption','store_quote_mutation'] LOOP
  EXECUTE format('ALTER TABLE ritc.%I ENABLE ROW LEVEL SECURITY',t);
  EXECUTE format('ALTER TABLE ritc.%I FORCE ROW LEVEL SECURITY',t);
  EXECUTE format('CREATE POLICY tenant_scope ON ritc.%I USING(household_id::text=(SELECT current_setting(''app.household_id'',true))) WITH CHECK(household_id::text=(SELECT current_setting(''app.household_id'',true)))',t);
  EXECUTE format('GRANT SELECT,INSERT ON ritc.%I TO ritc_app',t);
 END LOOP;
END $$;
GRANT UPDATE ON ritc.shop_budget_grant TO ritc_app;
ALTER FUNCTION ritc.privacy_erase_extension(uuid,uuid) RENAME TO privacy_erase_shared_ideas;
CREATE FUNCTION ritc.privacy_erase_extension(target_household uuid,target_member uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 DELETE FROM ritc.store_quote_mutation WHERE household_id=target_household AND actor_id=target_member;
 DELETE FROM ritc.store_quote_adoption WHERE household_id=target_household AND actor_id=target_member;
 DELETE FROM ritc.store_quote_pair WHERE household_id=target_household AND actor_id=target_member;
 DELETE FROM ritc.shop_budget_grant WHERE household_id=target_household AND member_id=target_member;
 PERFORM ritc.privacy_erase_shared_ideas(target_household,target_member);
END $$;
REVOKE ALL ON FUNCTION ritc.privacy_erase_extension(uuid,uuid) FROM PUBLIC;
