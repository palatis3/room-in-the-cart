## Gen 15 first-release register

Of the 56 traced decisions, 49 belong to the first release, one live retailer connection remains a separate research decision, and six exclusions define the product boundary. Earlier expansion headings now describe implementation work inside the first release. The baseline retailer handoff is a dated household-authored list.

### Start and plan · D01–D08

| ID and decision | Entitlement or release dependency | First-release behavior and acceptance check |
| --- | --- | --- |
| D01 · Start without setup | Free | Open a quick check without an account, store, subscription or weekly menu. Two pack offers and the amount needed produce an item-level answer. |
| D02 · Bring the list | Free | Type, paste or share selected text. Keep the original, preview lines, search and undo. Pasting 12 wraps twice asks whether to merge or add. Linking six to tacos within the 12 leaves 12 on the list. |
| D03 · Describe this shop | Free | Set the cap's scope, currency, store, mode and slot when relevant. Enter an inclusive preview or just the facts available. A $35 dinner limit stays labeled dinner-only even if the other groceries are unknown. |
| D04 · Name meals and needs | Free | Record the meal, night, servings and purpose of each need alongside staples and nonfood. Hiding lunches from view preserves their two wraps alongside six for tacos and four for quesadillas. |
| D05 · Compare usable packages | Free | Compare whole packs by usable amount, price to buy enough and remainder after protected portions. A shopper can leave a weight or volume conversion unknown when its ingredient-specific basis is missing. |
| D06 · Compare current checkouts | Free basic budget preview | Compare two same-store, same-slot checkout previews with time, source, included fees and commitments. A $34.80 subtotal plus a $4.95 fee shows $39.75 against $38. An uncertain fee produces a conditional result. |
| D07 · Protect or defer a purchase | Free | Mark a line required, flexible or undecided. Offer keep, defer and leave unresolved. When the shopper defers filters, lunches keep their allocation and the filters reappear for review next shop. |
| D08 · Explain a change | Free | Preview changed lines, meals, packs and checkout before applying. Skip one dinner and check that its portion alone disappears. Undo restores the draft, including unrelated staples. |

### Handoff, pickup and recovery · D09–D16

| ID and decision | Entitlement or release dependency | First-release behavior and acceptance check |
| --- | --- | --- |
| D09 · Save a recoverable handoff | Free | Save a dated readable snapshot before copy, share or retailer open. Track each action separately from shopper-confirmed submission and retailer-confirmed amendment. Cancelling or opening an empty cart leaves the snapshot intact and the order unconfirmed. |
| D10 · Resolve a changed item | Free | Record an offer's affected lines, remaining original quantity, known price and local deadline. Check per-dish alternatives. At cutoff show Await pickup with the date/time and keep fill unknown until the bag arrives. |
| D11 · Record what came home | Free | Record no-fill, partial, wrong, late or split items. Separate received, usable and reserved amounts, meal repair and refunds. A delivered eight-pack with six usable and two reserved supplies four to dinner. Retrying the same delivery adds nothing. |
| D12 · Tell the cook | Free | Preview the complete dated instruction and revision in plain text before sharing. An Android caregiver can act without installing the app. Budget defaults private. Marking a version sent does not record acknowledgment. |
| D13 · Reopen next shop | Free | Reopen the last shop, reuse one familiar dinner and review outstanding staples in a new draft. If someone bought the coffee already, mark it handled and verify the new list has no coffee charge. |
| D14 · Read and recover offline | Free | Restart in airplane mode and open the latest local save and last sent snapshot. At large type and with VoiceOver, read the item, quantity, dinner and status without relying on color or a swipe. |
| D15 · Keep control of family data | Free, including after membership ends | Preview a scoped shared copy separately from a personal recovery file. Correct, undo, export readable and structured records, recover and delete with scope shown. Importing a backup beside newer records preserves them and offers help. |
| D16 · Learn from the first result | Free, consent optional | Let a shopper distinguish acted, unchanged, too late, unknown, already knew and wrong. Declining feedback leaves the trip usable. Measurement omits grocery text and assigns zero incremental benefit to an observed tie. |

### Contracts for the first release · F01–F09

| ID and decision | Entitlement or release dependency | First-release behavior and acceptance check |
| --- | --- | --- |
| F01 · Quantities and money | All quantities and calculations | Keep distinct IDs for lines, meal demands and packages, original text, decimal amount, unit, conversion basis, currency and rounding. Two 15 oz cans stay two packs. Dual printed measures describe one demand. |
| F02 · Sources and allocations | All list and meal edits | Retain each manual, meal or reservation contribution when merging compatible lines. Remove one recipe and verify that other meals, lunches and a manual staple survive. An excluded ingredient cannot become an accepted match. |
| F03 · Draft and sent versions | All shops, snapshots and retailer actions | Version usual meal, weekly draft, sent copy, confirmed order and actual fill independently. Apply against the reviewed base once. An edit to a submitted order remains a proposed amendment until confirmed by the retailer. |
| F04 · Price evidence | All money figures | Attach source, store, time, mode, slot, eligibility and included charges. Keep estimates, holds, posted charges, credits and top-ups distinct. $37.20 posted with a $2.40 pending credit still shows $37.20 paid. A net charge retains an included credit once. |
| F05 · Offline and sharing rights | All sharing and offline writes | Separate membership, link scope, editing and retailer action. Limit each shop to one active shopper. An authorized handover transfers that role. A forwarded note conveys information only. Retries deduplicate by operation while distinct real purchases survive. |
| F06 · Language and access | All languages and assistive access | Separate interface and recipient language from original food wording, units, currency and store region. Exercise long text, RTL layout, plurals and spoken labels. A US Spanish message preserves no-salt, pack size and USD. |
| F07 · Storage and recovery | All local records and exports | Version and migrate structured files with stable identities. Preview selected media and recovery scope. Reopening an identical source and revision finds its existing copy. A malformed file leaves local records intact and support needs no full receipt. |
| F08 · Connections and operations | Offline baseline and online household service | Distinguish copying a list, syncing a request, saving a family decision and reporting an order placed. A failed sync retains a retryable local draft. A copied list never confirms an order. |
| F09 · Purchase and measurement | All billing and measurement | Keep consent, eligible weeks, comparison baseline, membership and Apple billing separate. Exercise pending, restore, grace, cancellation, expiry and refund. A second device or refunded sale cannot count as a second willing household. |

### Household planning · P01–P08

| ID and decision | Entitlement or release dependency | First-release behavior and acceptance check |
| --- | --- | --- |
| P01 · Usual dinners and rotations | Household, with one reusable dinner free | Select multiple familiar dinners or selected nights of a rotation. Preserve dish-specific rules and overrides. Editing Wednesday in this week's copy leaves the next ordinary week intact. Compare total effort with reusing the family's existing template. |
| P02 · Pair dinners across the pack | Household or isolated preview | Pair familiar meals using unreserved food. Include all other ingredients, packs, fees, accepted portions and prep time. The three-pepper example must cover lunches in both alternatives before reporting a checkout change. |
| P03 · Adjust people and plans | Household automation, free manual edits | Adjust guests, nights away, vegetarian plates, lunches or sides. Preview the smallest change and cost. Moving from eight to nine needed wraps triggers a second eight-pack for review and preserves the lunches. |
| P04 · Recover tonight's dinner | Household suggestions, free manual repair | Filter the family's accepted meals against actual fill, confirmed yield, time, exclusions and protected portions. With an unavailable ingredient, show a feasible top-up or leave the need open. Compare time to using the household's usual fallback. |
| P05 · Prepare the next trip | Household assisted review, free open deferrals | Recall previously approved staples by purpose and store, then ask what is needed this trip. A month-old checked market item stays checked until reopened. Count re-entry time alongside prompts and duplicate purchases. |
| P06 · Show what changed since sending | Household automated comparison, free dated copies | Compare adds, removals and unresolved items against the last intentional handoff to this recipient. A stale edit requires review. If a prior message may have gone elsewhere, the correction includes the full current instruction. |
| P07 · Family decision history | Household history tools, free access to saved records | Find past dish-specific approvals, exclusions and what actually happened. Missing outcomes stay unconfirmed. Retaining an emergency substitute as a lasting preference requires the household's explicit choice. |
| P08 · One household offer | One Household entitlement for two named adults on supported iPhones | Show proposed $49.99 yearly total, renewal, Apple confirmation, manage and restore. Verify second-seat access and recovery. Pending purchases do not activate tools. After expiry, records open and export and one dinner remains reusable. A seat grants no automatic shop access. |

### Import, shared access, language and retailer connection · E01–E05

| ID and decision | Entitlement or release dependency | First-release behavior and acceptance check |
| --- | --- | --- |
| E01 · Bring a recipe library | Manual entry free. Supported file format and migration fixtures required. | Import one documented recipe-library file format with title, servings, source, notes and linked needs. Preview matches, duplicates and skipped rows, then undo the entire batch. A malformed file must preserve existing meals. |
| E02 · Photo and scan | Optional capture with supported camera, photo picker or local recognition | Attach a package reference photo. Offer reviewed recipe OCR, barcode identification and receipt-line capture. Preserve original text/image for comparison, flag unreadable quantities and allow typing. A low-light bilingual capture can be corrected without confirming a price or marking an item received. |
| E03 · Current shared view | Scoped online shared view, separate contributor and shopper grants | Share a revocable, expiring current view for one shop on iPhone or Android/browser. A separately authorized editor reviews conflicting stale changes. Keep one active shopper. A contributor sees only their own requests. Revoking a link blocks fresh reads and edits. Label offline copies with their save time. |
| E04 · Spanish handoff and interface | Human-reviewed US English and US Spanish strings, help and purchase copy | Support handoffs in both language directions and the full core and subscription flows in US Spanish. Preserve original item text and allow edits. Check pack count, local date, exclusion and amount due with speakers of both languages, including after a locale change. |
| E05 · Confirmed retailer connection | Research only, outside the Gen 15 release | Keep the historical ID to preserve the decision trail. The shipped handoff is copy or share of shopper-reviewed household lines and user-directed checkout. No provider credential, integration or live retailer access is a release prerequisite. |

### Carryover, shopping access, reminders, history and coverage · E06–E10

| ID and decision | Entitlement or release dependency | First-release behavior and acceptance check |
| --- | --- | --- |
| E06 · Pantry and freezer carryover | Optional household-entered storage and batch details | Record a dated pantry or freezer batch, usable quantity, reservations and a use-first hint. Confirm before carrying food into a dinner. Five portions cannot cover four dinners and two lunches. A correction updates dependent meals once. |
| E07 · Faster shopping access | Supported iPhone surfaces, with privacy and accessibility checks | Provide store labels, aisle grouping, keyboard dictation, a scoped widget, selected-text share extension and large-print list. Compare finding one item across long lists. The locked widget hides budget/private notes and a cancelled share import leaves the draft intact. |
| E08 · Optional reminders | Free, explicit notification permission | Choose a specific deferral or offer deadline, local time, quiet hours and expiry. A delayed notice after cutoff opens Await pickup. Turning reminders off leaves the ordinary shop usable. |
| E09 · Price and budget history | Household history and period planning, free current-shop budget preview | Review household-entered prices by store and mode. Reserve future shops in an optional pay-period envelope. Distinguish warehouse from web, deferred spend from savings, and incomplete periods from verified balances. Restrict budget and payment information to authorized adults. |
| E10 · Other surfaces and markets | US launch coverage, mobile web on supported browsers, market-by-market release checks | A helper on Android/browser can receive instructions and submit, inspect or withdraw their own request within shop rules. Gate specific chain, language, currency, unit and market claims on local checkout fixtures and support. Test the mixed-phone task without a native companion or adult account sharing. |

### New first-release decisions · N01–N07

| ID and decision | Entitlement or release dependency | First-release behavior and acceptance check |
| --- | --- | --- |
| N01 · Family request inbox | Free on participating phones, including invited kids with the appropriate guardian setup | An invited author types or speaks, reviews and submits. Only the active shopper may merge, add, defer or dismiss. Show the shopper the full-budget preview first. Locking for checkout protects the basket. Placement routes new and undecided requests to Next shop. Deduplicate retries. Contributors receive only their own request status and no budget or payment fields. |
| N02 · Structured speech entry | Free request entry, optional speech with a typed equivalent | Preview item, pack count, amount and destination. Correct one field. A contributor confirms a request only. For the shopper, selecting Apply can update the local planning draft. A retry affects the intended record exactly once. |
| N03 · Dinner readback | Free, optional on-device playback where supported | Read the selected current cooking instruction with pause, stop and repeat. Use confirmed usable quantity and reservations, keep the dated text visible and omit private budget by default. VoiceOver and readback must not talk over one another. |
| N04 · Product-name corrections | Optional, device-local and editable | After the user corrects a recognized product name, offer to remember that correction. Show it for review at the next matching entry, preserve original wording and let the user forget it without changing past records. |
| N05 · Source on manual recipe | Free manual recipe entry | Paste an optional source URL alongside the family's own meal title, servings and notes. A failed import or vanished page leaves the editable dinner and its weekly allocations intact. |
| N06 · Recovery comparison | Free record and backup recovery | Compare the selected backup's source, date, revision and affected records with newer local work. Preview which records match, conflict or are absent, then recover separately. Cancelling or importing a corrupt file makes no changes. |
| N07 · Spoken guest preview | Household guest automation or isolated preview, free manual guest edit | Say one more guest, confirm which meal and count, then review pack, protected lunch and checkout effects on screen. Cancel discards the preview. Apply once creates a draft revision, and any order amendment still needs retailer confirmation. |

### Explicit exclusions · X01–X06

| ID and decision | Entitlement or release dependency | First-release behavior and acceptance check |
| --- | --- | --- |
| X01 · Grocery marketplace and delivery | Excluded | The shopper completes payment, slot selection and ordering with the retailer. Copy and share never create an ordered or delivered state. |
| X02 · Universal deals and store routing | Excluded | Confine checkout alternatives to the identified shop with matched terms. No universal deal finder, chain price leaderboard or automatic second-store itinerary appears. |
| X03 · Medical or allergy decisions | Excluded | Respect household-entered hard exclusions and let the family decline any replacement. A scanned name or translation cannot certify allergen safety or suitability for a medical condition. |
| X04 · Broad generated recipes and nutrition coaching | Excluded | Offer approved meals and manual entries. Leave a need open when none fit. No generic recipe generation, nutrition targets, diet coaching or calorie dashboard. |
| X05 · Social feed and family calendar | Excluded | Record an away night or guest against the meal. A contributor request stays private to its authorized participants. No social feed, school schedule or full family calendar. |
| X06 · Mandatory scanning and credential scraping | Excluded | Complete a shop by typing and manual retailer review with camera access denied and no retailer password in the planner. Optional scan review and official shopper authorization remain distinct routes. |
