# Gen 15 screen walkthrough

The 20 established screens keep their identifiers. Four new screens cover household invitations, contributor entry, the shopper inbox and the budget decision. Shared requests are free, including on the supported mobile-web contribution surface. The shopper’s expected checkout and the child’s request status use different views of the same decision.

## Invite the household and review a request

### S21 · Invite and manage household contributors

**Organizer or guardian · Household settings · Free.** Choose an adult contributor or a guardian-managed child profile. Explain exactly which information that person can see. For child participation, complete the guardian flow before activating online requests. Redeem a single-use, expiring invite on the intended device. Show the alias, role, devices and revoke action. Manage adult paid seats separately in S19. A contributor invite cannot be redeemed as a shopper or paid seat.

### S22 · Ask the shopper

**Invited contributor · iPhone or supported mobile web · Free.** Type “cereal” or speak it, review the item and amount, and select Send request. Show the current household before sending, particularly when a member belongs to more than one. The requester sees only their own pending, deferred, handled or dismissed requests. Offline, say “Waiting to sync.” While checkout is protected or after placement, explain “This request will go to the next shop.” Leave an unconfirmed quantity as a question.

### S23 · Review family requests

**Active shopper · Shop inbox · Free.** Show Sam, cereal, one box, request revision and server-received time. Group likely duplicates but retain their sources. Mia can clarify with the requester through a scoped status or resolve the question herself. Preview either one shared box or an additional box in S24. Mark an item already handled when another adult bought it. Keep completed entries reachable so Mia can inspect an earlier decision.

### S24 · Choose this pickup or the next

**Active shopper · Decision sheet · Free.** Show current shop, matched package, price basis, before and after totals, cap and any affected meals. Present **Add to this pickup** and **Save for next shop**. Show the overage before allowing an explicit over-budget choice. Cancel leaves the request pending. Commit the updated shop line, status and receipt of the shopper’s decision once. If the order closes or quantity changes mid-review, refresh or route to Next shop. A contributor cannot open this screen.

## Bring the list and understand one item

### S01 · Start or resume

**Shop · Free.** Open a quick pack comparison, resume a dated pickup or check something missing without an account. A household shopper can open the inbox from the current shop. Signed-in contributors land on their own requests. An offline resume shows the last local save and last household sync separately.

### S02 · Bring the list

**Shop · Free.** Type, dictate, paste or explicitly import a supported source. Preview original text beside parsed lines. Keep a visible checkbox distinct from opening item details. Recently checked remains accessible. “Two reserved for lunches” stays within the typed total unless the shopper explicitly adds more. Contributions from other people remain in the inbox until accepted.

### S03 · Describe this pickup

**Shop · Free.** Record the cap, store, pickup or delivery mode, slot and included charges when the decision needs them. Keep a dinner-only cap distinct from total checkout. A change of store, slot or mode invalidates dependent comparisons. Show fees and dates before committing.

### S04 · Inspect an ingredient

**Shop or Dinners · Free.** Display pack size, quantity basis, manually added staples and each meal or lunch commitment. See which request an accepted line satisfies. A second person asking for a similar item never doubles demand automatically. Changing the source preserves unrelated meal reservations.

## Complete the pickup and inspect the bags

### S05 · Compare checkout choices

**Shop · Free.** Compare options on the same basis, including fees and protected portions. Show what can wait and what remains unknown. Select one option or keep the existing draft. A known lower checkout can still exceed the cap. The private budget is visible only to an authorized adult.

### S06 · Prepare the retailer handoff

**Shop · Active shopper · Free.** Freeze a dated snapshot and copy or share the reviewed household lines. The live inbox switches new requests to Next shop during checkout. On return, choose **I placed this order**, **Still checking out** or **Reopen draft**. Mark the source of placement evidence. Selecting Copy or closing the share sheet cannot mark the order placed.

### S07 · Review a store offer

**Shop · Free.** Enter the offered substitute, amount, price and local deadline. Recalculate meal coverage only with the quantities the family can support. An expired offer becomes Await pickup. Record the retailer’s actual response separately from the family’s preference. An optional reminder expires at the decision deadline.

### S08 · Record what came home

**Shop · Free.** Verify a delivered line once. Keep one received pack distinct from the number of usable wraps. In the six-usable example, two go to lunches, four of six go to tacos, and quesadillas still need four. An unchecked line stays unverified. A receipt or photograph is evidence to review, not a count of usable food.

## Repair dinner and start next week

### S09 · Repair the meal

**Dinners · Free manual repair, Household assisted choices.** Show the affected dinner, shortage and reserved portions. Enter a replacement, confirm food, timing and exclusions, or leave the need open. Resolving Wednesday’s meal cannot erase Tuesday’s separate shortage. Review a freezer portion before using it.

### S10 · Tell the cook

**Dinners · Free handoff and readback.** Preview one dated, self-contained instruction. Read aloud on request with pause, stop and repeat. Retain text for silent reading and mixed phones. Omitting a budget or private note is the default for each new handoff. Sending, receipt, acknowledgment and purchase are distinct.

### S11 · Close the pickup

**Records · Free.** Enter posted charges, pending adjustments and known top-ups. Distinguish a refund included in a net charge from a separate credit. Mark a contributor’s item bought only after explicit confirmation. Save unknowns for later. Each measured household shop counts once.

### S12 · Start the next shop

**Shop · Free carryover, Household assisted review.** Show deferred staples, family requests saved for next shop and what was already handled. Ask if the item is still needed. Price it again, choose the actual package and show the cap effect. The new shop starts with no automatic charges from yesterday’s inbox.

## Plan meals and handle a guest

### S13 · Choose a way to plan

**Dinners · Free entry and isolated Household preview.** Reuse one familiar dinner or enter meals manually. Try a Household pairing on a copy without billing. Applying a preview requires the current shopper’s approval for that shop. Declining leaves the free route available.

### S14 · Choose familiar dinners

**Dinners · Free manual, Household multi-meal reuse.** Retain household portions, dish-specific exclusions, original wording and a source link. Preview recipe-library imports and list skipped fields. Save a lasting preference only when the family chooses. One guest is a change to this week.

### S15 · Pair dinners across a pack

**Dinners · Household or preview.** Hold diners, lunch coverage and all other commitments comparable. Show the whole change in packs, fees, prep time and checkout. An unused pepper alone does not make the second dinner free. Keep a viable alternative if any needed price or ingredient is unknown.

### S16 · Add a guest

**Shop or Dinners · Household assisted, free manual equivalent.** Tap or speak a guest change. Confirm dinner and guest count, check other ingredients and preserve lunch allocations. Show the new total and flexible lines. A spoken what-if produces a preview. A second planning adult can propose it to the shopper.

## Confirm a revision and preserve access

### S17 · Apply and explain a revision

**Shop · Household assisted comparison, free manual changes and snapshots.** Compare with the known recipient version and the shop base used for approval. Commit once. If the destination is uncertain, supply a complete fresh instruction. A placed order requires a separate shopper action and retailer confirmation for any amendment.

### S18 · Decide on Household

**Adult purchase flow.** Explain the proposed annual two-adult planning offer, renewal and restore terms, with a clear free route. Separate the price test from confirmed billing. Family requests, basic cap checks, manual planning, readback of owned records and exports remain available after lapse. Never show a paywall on a child’s contribution screen.

### S19 · Manage the two seats

**Adult membership settings.** Invite a named second planner, review seat status or restore an entitlement. A paid seat never grants control over every shop. An organizer can transfer one active-shop role to another authorized adult through the online household service. Member removal and subscription cancellation have separate effects.

### S20 · Find records and recover files

**Records · Free.** Reopen saved shops offline and distinguish local save, last sync and last exported backup. Compare source, revision, conflicts and dates before importing. A helper file has a narrow allowlist. A backup cannot recreate a revoked member, child-consent grant or paid seat. On recovery, apply deletion history before showing records to a newly connected device.
